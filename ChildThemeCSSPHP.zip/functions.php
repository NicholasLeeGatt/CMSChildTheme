<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );

if ( !function_exists( 'chld_thm_cfg_parent_css' ) ):
    function chld_thm_cfg_parent_css() {
        wp_enqueue_style( 'chld_thm_cfg_parent', trailingslashit( get_template_directory_uri() ) . 'style.css', array( 'zita-font-awesome','zita-menu-style' ) );
    }
endif;
add_action( 'wp_enqueue_scripts', 'chld_thm_cfg_parent_css', 10 );
         
if ( !function_exists( 'child_theme_configurator_css' ) ):
    function child_theme_configurator_css() {
        wp_enqueue_style( 'chld_thm_cfg_ext1', trailingslashit( get_theme_root_uri() ) . 'zita-child/Zita/single.php' );
    }
endif;
add_action( 'wp_enqueue_scripts', 'child_theme_configurator_css', 100 );

// END ENQUEUE PARENT ACTION
function getUserAmount() {
    $users = get_users(); // Get all wordpress users

    if ( empty( $users ) ) { // If there aren't any users display an error
      return 'There aren\'t any users to display.';
    }
    return '<marquee>User Registered to NLG VICE <span style="color: #FF4F4F ">'. count($users) .'</span></marquee>'; // Return amount of users
}
/* Preparing to serve an API request */
add_action( 'rest_api_init', function () {
    register_rest_route( '/wp/v2', '/users', 
        array(
            'methods' => 'GET',
            'callback' => 'getUserAmount',
        )
    );
} );

function displayUsers(){
   add_shortcode('users-count', 'getUserAmount');
}
add_action( 'init', 'displayUsers');

function isa_add_cron_recurrence_interval( $schedules ) {
$schedules['every_second'] = array(
    'interval'  => 1,
    'display'   => __( 'Every second', 'textdomain' )
);
	
return $schedules;
}
add_filter( 'cron_schedules', 'isa_add_cron_recurrence_interval' );

function my_activation() {
if (! wp_next_scheduled ( 'my_event' )) {
    wp_schedule_event(time(), 'every_second', 'my_event');
}
}

add_action('my_event', 'displayUsersLoggedIn');
	
function getUserLoggedInAmount() {
    $current_user = wp_get_current_user(); // Get all wordpress users
	if ( is_user_logged_in() ) { 
        return '<p>Welcome To NLG Vice <a href="http://nlgofficial.com/account/"><span class="loggedinUser" style="color: #FFCFCF">'. $current_user->user_login .'.</a></span> Thanks for logging in and joining.</p>';
    }
	else{
		return '<p>You are currently not logged in. You can log in <a href="http://nlgofficial.com/login/"><span style="color: #FF4F4F "> here </a></span> or register <a href="http://nlgofficial.com/register/"><span style="color: #FF4F4F "> here </a></span>.</p>';
	}// Return amount of users
}
/* Preparing to serve an API request */
add_action( 'rest_api_init', function () {
    register_rest_route( '/wp/v2', '/users', 
        array(
            'methods' => 'GET',
            'callback' => 'getUserLoggedInAmount',
        )
    );
} );

function displayUsersLoggedIn(){
   add_shortcode('users-loggedIncount', 'getUserLoggedInAmount');
}
add_action( 'init', 'displayUsersLoggedIn');


function gt_get_post_view() {
    $count = get_post_meta( get_the_ID(), 'post_views_count', true );
	return '<p> Product Viewed: <span class="loggedinUser" style="color: #FFCFCF"> '. $count .' </spam>times</p>';
}
function gt_set_post_view() {
    $key = 'post_views_count';
    $post_id = get_the_ID();
    $count = (int) get_post_meta( $post_id, $key, true );
    $count++;
    update_post_meta( $post_id, $key, $count );
}
function gt_posts_column_views( $columns ) {
    $columns['post_views'] = 'Views';
    return $columns;
}
function gt_posts_custom_column_views( $column ) {
    if ( $column === 'post_views') {
        echo gt_get_post_view();
    }
}
add_filter( 'manage_posts_columns', 'gt_posts_column_views' );
add_action( 'manage_posts_custom_column', 'gt_posts_custom_column_views' );


function displayPostViews(){
   add_shortcode('post-views', 'gt_get_post_view');
}
add_action( 'init', 'displayPostViews');

function welcome(){
 
   if(date("H") < 12){
 
     return '<p class="introGreetPos"><span class="introGreet" style="color: #FFCFCF"> Good Morning </span>, Welcome to NLG Vice</p> ';
 
   }elseif(date("H") > 11 && date("H") < 18){
 
     return '<p class="introGreetPos"><span class="introGreet" style="color: #FFCFCF"> Good Afternoon </span>, Welcome to NLG Vice</p> ';
 
   }elseif(date("H") > 17){
 
 	 return '<p class="introGreetPos"><span class="introGreet" style="color: #FFCFCF"> Good Evening </span>, Welcome to NLG Vice</p> ';
   }
 
} 


function displayGreet(){
   add_shortcode('welcome-greet', 'welcome');
}
add_action( 'init', 'displayGreet');

function displayDB(){
	
	
	global $wpdb;
	$preJSON = array(); 
	 $sql = "SELECT * FROM wp_sh_products";
	$count = 0;
	foreach( $wpdb->get_results( $sql ) as $key => $row ) {
		$prodid = $row->id;
		$prodname = $row->product_name;
		$prodtype = $row->product_type;
		$prodquan = $row->quantity;
		$prodprice = $row->price;
		
		$preJSON[$count] = array(
			"Id" =>	$prodid,
			"Name" => $prodname,
			"Type" => $prodtype,
			"Quantity" => $prodquan,
			"Price" => $prodprice
		);
		++$count;
	}
	  //change as below.
	  return json_encode($preJSON);
}





